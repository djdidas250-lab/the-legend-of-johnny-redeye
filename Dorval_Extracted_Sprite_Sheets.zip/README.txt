The Legend of Dorval — extracted character sprite sheets

Eight transparent PNG sprite strips. Each frame is 360x380 pixels (2x pixel-art upscale), with a common 180x190 logical cell.

David: david_walk (6), david_attack (4), david_hurt (4).
Enemies: enemy_punk, enemy_plaid, enemy_purple, enemy_hooded, enemy_construction (6 frames each).

Source images: 1000015030.jpg, 1000015031.jpg, 1000015033.jpg.
